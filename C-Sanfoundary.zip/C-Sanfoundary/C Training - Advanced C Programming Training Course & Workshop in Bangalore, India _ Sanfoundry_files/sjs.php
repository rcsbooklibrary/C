 document.write ("<scr"+"ipt type='text/javascript'>"); document.write ('(new Image()).src = \'https://x.fidelity-media.com/pixel.php?dsp=smtyn\';'); document.write ('(new Image()).src = \'https://x.fidelity-media.com/pixel.php?dsp=aolhbc\';'); document.write ('(new Image()).src = \'https://x.fidelity-media.com/pixel.php?dsp=adfrs\';'); document.write ('(new Image()).src = \'https://x.fidelity-media.com/pixel.php?dsp=ntvny\';'); document.write ('(new Image()).src = \'https://x.fidelity-media.com/pixel.php?dsp=smtyn\';'); document.write ('(new Image()).src = \'https://x.fidelity-media.com/pixel.php?dsp=smtyn\';'); document.write ('(new Image()).src = \'https://x.fidelity-media.com/pixel.php?dsp=ntvb\';'); document.write ('(new Image()).src = \'https://x.fidelity-media.com/pixel.php?dsp=bidswn\';'); document.write ("<\/scr"+"ipt>");  function getFlashVersion(){
    var plugins, plugin, result;
    if (navigator.plugins && navigator.plugins.length > 0) {
      plugins = navigator.plugins;
      for (var i = 0; i < plugins.length && !result; i++) {
        plugin = plugins[i];
        if (plugin.name.indexOf("Shockwave Flash") > -1) {
          result = plugin.description.split("Shockwave Flash ")[1];
        }
      }
    }
    return result ? result : "";
  }
  
  var m3_u = (location.protocol=='https:'?'https://x.fidelity-media.com/delivery/ajs.php':'http://x.fidelity-media.com/delivery/ajs.php');
  var m3_r = Math.floor(Math.random()*99999999999);
  if (!document.MAX_used) document.MAX_used = ',';
  document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
  document.write ("?zoneid=33038");
  document.write ("&amp;from=sjs");
  document.write ("&amp;cb=" + m3_r);
  document.write ("&amp;ab=1530707409" + m3_r);
  if (document.MAX_used !== ',') document.write ("&amp;exclude=" + document.MAX_used);
  document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
    var loc = document.referrer;
  try { if (window.top == window) loc = window.location.href; } catch(e) {}
  document.write ("&amp;defloc=" + encodeURIComponent(loc)); 
  document.write ("&amp;altloc=" + encodeURIComponent(window.location.href));
  
  if (document.referrer) document.write ("&amp;referer=" + encodeURIComponent(document.referrer));
  if (document.context) document.write ("&amp;context=" + encodeURIComponent(document.context));
  
  if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
  document.write("&amp;flashver=" + encodeURIComponent(getFlashVersion()));
  document.write ("'><\/scr"+"ipt>");